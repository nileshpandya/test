$(document).ready(function($){

	// tab 
	$('ul.tabs li').click(function(){
		var tab_id = $(this).attr('data-tab');

		$('ul.tabs li').removeClass('current');
		$('.tab-content').removeClass('current');

		$(this).addClass('current');
		$("#"+tab_id).addClass('current');
	})
	
	
	
	
	$(".testimonial-slider").slick({
		dots: false,
		autoplay: false,
		//autoplaySpeed: 8000,
		infinite: true,
		centerMode: true,
		arrows: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		centerPadding: '300px',
		responsive: [
			{
			breakpoint: 1200,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					centerPadding: '140px'
				}
			},
			{
			breakpoint: 1000,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					centerPadding: '100px'
				}
			},
			{
			breakpoint: 800,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					centerPadding: '80px'
				}
			},
			{
			breakpoint: 600,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					centerPadding: '0px'
				}
			},
			{
			breakpoint: 500,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					centerPadding: '0px'
				}
			}
		]
	});

	
	
});